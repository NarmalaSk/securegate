"use client";

import { useEffect } from "react";

export default function CallbackPage() {
  useEffect(() => {
    const hash = window.location.hash;
    const params = new URLSearchParams(hash.startsWith("#") ? hash.slice(1) : hash);

    const accessToken = params.get("access_token");
    const idToken = params.get("id_token");

    if (accessToken) {
      localStorage.setItem("demo_access_token", accessToken);
    }

    if (idToken) {
      localStorage.setItem("demo_id_token", idToken);
    }

    window.location.replace("/");
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-950 text-slate-100">
      Processing login...
    </div>
  );
}