"use client";

import React, { useEffect, useMemo, useState } from "react";

const AUTH0_DOMAIN = process.env.NEXT_PUBLIC_AUTH0_DOMAIN || "";
const AUTH0_CLIENT_ID = process.env.NEXT_PUBLIC_AUTH0_CLIENT_ID || "";
const AUTH0_AUDIENCE = process.env.NEXT_PUBLIC_AUTH0_AUDIENCE || "";
const REDIRECT_URI =
  process.env.NEXT_PUBLIC_AUTH0_REDIRECT_URI || "http://localhost:3000/callback";
const BACKEND_URL = process.env.NEXT_PUBLIC_BACKEND_URL || "http://127.0.0.1:8000";
const GOOGLE_CONNECTION =
  process.env.NEXT_PUBLIC_AUTH0_GOOGLE_CONNECTION || "google-oauth2";

function buildAuthorizeUrl(params: Record<string, string>) {
  const url = new URL(`https://${AUTH0_DOMAIN}/authorize`);
  Object.entries(params).forEach(([key, value]) => url.searchParams.set(key, value));
  return url.toString();
}

type MeResponse = {
  sub: string;
  email?: string;
  scope?: string;
  permissions?: string[];
};

type EmailItem = {
  id: string;
  threadId: string;
  snippet?: string;
  subject?: string;
  from_?: string;
};

type GmailProfile = {
  emailAddress: string;
  messagesTotal?: number;
  threadsTotal?: number;
  historyId?: string;
};

export default function GmailAgentDemoPage() {
  const [accessToken, setAccessToken] = useState("");
  const [status, setStatus] = useState("Idle");
  const [me, setMe] = useState<MeResponse | null>(null);
  const [emails, setEmails] = useState<EmailItem[]>([]);
  const [gmailProfile, setGmailProfile] = useState<GmailProfile | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const isConfigured = useMemo(() => {
    return Boolean(AUTH0_DOMAIN && AUTH0_CLIENT_ID && AUTH0_AUDIENCE);
  }, []);

  useEffect(() => {
    const savedAccessToken = localStorage.getItem("demo_access_token") || "";
    if (savedAccessToken) {
      setAccessToken(savedAccessToken);
      setStatus("Restored local session token.");
    }
  }, []);

  const login = () => {
    setError("");
    if (!isConfigured) {
      setError("Missing NEXT_PUBLIC Auth0 env vars.");
      return;
    }

    const authorizeUrl = buildAuthorizeUrl({
      response_type: "token id_token",
      client_id: AUTH0_CLIENT_ID,
      redirect_uri: REDIRECT_URI,
      audience: AUTH0_AUDIENCE,
      scope: "openid profile email",
      nonce: crypto.randomUUID(),
      state: crypto.randomUUID(),
    });

    window.location.href = authorizeUrl;
  };

  const connectGoogle = () => {
    setError("");
    if (!isConfigured) {
      setError("Missing NEXT_PUBLIC Auth0 env vars.");
      return;
    }

    const authorizeUrl = buildAuthorizeUrl({
      response_type: "token id_token",
      client_id: AUTH0_CLIENT_ID,
      redirect_uri: REDIRECT_URI,
      audience: AUTH0_AUDIENCE,
      scope: "openid profile email",
      connection: GOOGLE_CONNECTION,
      connection_scope: "https://www.googleapis.com/auth/gmail.readonly",
      prompt: "consent",
      nonce: crypto.randomUUID(),
      state: crypto.randomUUID(),
    });

    window.location.href = authorizeUrl;
  };

  const logout = () => {
    localStorage.removeItem("demo_access_token");
    localStorage.removeItem("demo_id_token");
    setAccessToken("");
    setMe(null);
    setEmails([]);
    setGmailProfile(null);
    setStatus("Logged out locally.");
    setError("");

    if (AUTH0_DOMAIN && AUTH0_CLIENT_ID) {
      const url = new URL(`https://${AUTH0_DOMAIN}/v2/logout`);
      url.searchParams.set("client_id", AUTH0_CLIENT_ID);
      url.searchParams.set("returnTo", "http://localhost:3000");
      window.location.href = url.toString();
    }
  };

  const callBackend = async <T,>(path: string, init?: RequestInit): Promise<T> => {
    const token = localStorage.getItem("demo_access_token") || accessToken;

    if (!token) {
      throw new Error("No Auth0 access token found. Login first.");
    }

    const response = await fetch(`${BACKEND_URL}${path}`, {
      ...init,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
        ...(init?.headers || {}),
      },
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      throw new Error(typeof data === "string" ? data : JSON.stringify(data, null, 2));
    }

    return data as T;
  };

  const fetchMe = async () => {
    setLoading(true);
    setError("");
    try {
      const data = await callBackend<MeResponse>("/api/me");
      setMe(data);
      setStatus("Backend token validation worked.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unknown error");
    } finally {
      setLoading(false);
    }
  };

  const fetchGmailProfile = async () => {
    setLoading(true);
    setError("");
    try {
      const data = await callBackend<GmailProfile>("/api/gmail/profile");
      setGmailProfile(data);
      setStatus("Fetched connected Gmail profile.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unknown error");
    } finally {
      setLoading(false);
    }
  };

  const fetchEmails = async () => {
    setLoading(true);
    setError("");
    try {
      const data = await callBackend<{ messages: EmailItem[] }>(
        "/api/gmail/recent?max_results=5"
      );
      setEmails(data.messages || []);
      setStatus("Fetched Gmail messages through backend.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unknown error");
    } finally {
      setLoading(false);
    }
  };

  const summarizeEmails = async () => {
    setLoading(true);
    setError("");
    try {
      const data = await callBackend<{ summary: string; emails: EmailItem[] }>(
        "/api/gmail/summarize",
        {
          method: "POST",
          body: JSON.stringify({
            prompt: "Summarize my latest inbox items",
            max_results: 5,
          }),
        }
      );
      setEmails(data.emails || []);
      setStatus(data.summary || "Summary call completed.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unknown error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-6">
      <div className="max-w-5xl mx-auto grid gap-6">
        <div className="rounded-3xl border border-slate-800 bg-slate-900 p-6 shadow-2xl">
          <h1 className="text-3xl font-bold">Gmail Agent Demo</h1>
          <p className="text-slate-300 mt-2">
            Auth0 login + Google connect + FastAPI Gmail backend.
          </p>

          <div className="mt-5 flex flex-wrap gap-3">
            <button
              onClick={login}
              className="rounded-2xl px-4 py-2 bg-white text-black font-semibold"
            >
              Login with Auth0
            </button>

            <button
              onClick={connectGoogle}
              className="rounded-2xl px-4 py-2 bg-sky-500 text-white font-semibold"
            >
              Connect Gmail
            </button>

            <button
              onClick={fetchMe}
              disabled={!accessToken || loading}
              className="rounded-2xl px-4 py-2 bg-slate-700 disabled:opacity-50"
            >
              Test /api/me
            </button>

            <button
              onClick={fetchGmailProfile}
              disabled={!accessToken || loading}
              className="rounded-2xl px-4 py-2 bg-amber-600 disabled:opacity-50"
            >
              Show Connected Gmail
            </button>

            <button
              onClick={fetchEmails}
              disabled={!accessToken || loading}
              className="rounded-2xl px-4 py-2 bg-emerald-600 disabled:opacity-50"
            >
              Fetch Emails
            </button>

            <button
              onClick={summarizeEmails}
              disabled={!accessToken || loading}
              className="rounded-2xl px-4 py-2 bg-violet-600 disabled:opacity-50"
            >
              Summarize
            </button>

            <button
              onClick={logout}
              className="rounded-2xl px-4 py-2 bg-rose-700 text-white font-semibold"
            >
              Logout
            </button>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <div className="rounded-3xl border border-slate-800 bg-slate-900 p-6">
            <h2 className="text-xl font-semibold">Status</h2>
            <p className="mt-3 text-sm text-slate-300 break-words">{status}</p>

            {error && (
              <pre className="mt-4 whitespace-pre-wrap rounded-2xl bg-rose-950/50 border border-rose-800 p-4 text-rose-200 text-sm overflow-auto">
                {error}
              </pre>
            )}

            <div className="mt-4 text-sm text-slate-400 space-y-2">
              <p><strong>Backend:</strong> {BACKEND_URL}</p>
              <p><strong>Redirect URI:</strong> {REDIRECT_URI}</p>
              <p><strong>Audience:</strong> {AUTH0_AUDIENCE || "missing"}</p>
              <p><strong>Google Connection:</strong> {GOOGLE_CONNECTION}</p>
              <p>
                <strong>Connected Gmail:</strong>{" "}
                {gmailProfile?.emailAddress || "Not loaded yet"}
              </p>
            </div>
          </div>

          <div className="rounded-3xl border border-slate-800 bg-slate-900 p-6">
            <h2 className="text-xl font-semibold">Session</h2>
            <div className="mt-4 space-y-4">
              <div>
                <p className="text-sm text-slate-400 mb-1">Access Token Present</p>
                <p className="text-sm break-all">{accessToken ? "Yes" : "No"}</p>
              </div>

              <div>
                <p className="text-sm text-slate-400 mb-1">User Info</p>
                <pre className="whitespace-pre-wrap rounded-2xl bg-slate-950 border border-slate-800 p-4 text-sm overflow-auto min-h-[140px]">
                  {JSON.stringify(me, null, 2)}
                </pre>
              </div>

              <div>
                <p className="text-sm text-slate-400 mb-1">Gmail Profile</p>
                <pre className="whitespace-pre-wrap rounded-2xl bg-slate-950 border border-slate-800 p-4 text-sm overflow-auto min-h-[140px]">
                  {JSON.stringify(gmailProfile, null, 2)}
                </pre>
              </div>
            </div>
          </div>
        </div>

        <div className="rounded-3xl border border-slate-800 bg-slate-900 p-6">
          <h2 className="text-xl font-semibold">Recent Emails</h2>
          <div className="mt-4 grid gap-4">
            {emails.length === 0 ? (
              <p className="text-slate-400">No emails fetched yet.</p>
            ) : (
              emails.map((email) => (
                <div
                  key={email.id}
                  className="rounded-2xl border border-slate-800 bg-slate-950 p-4"
                >
                  <p className="font-semibold text-base">
                    {email.subject || "(No subject)"}
                  </p>
                  <p className="text-sm text-slate-400 mt-1">
                    From: {email.from_ || "Unknown"}
                  </p>
                  <p className="text-sm text-slate-300 mt-3">
                    {email.snippet || "No snippet"}
                  </p>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}